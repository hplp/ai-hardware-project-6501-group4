import torch
from torchvision import models
import numpy as np

# 加载预训练的 ResNet18 模型
model = models.resnet18(pretrained=True)
model.eval()

# 创建一个随机输入数据（模拟 224x224x3 的图片）
input_data = torch.randn(1, 3, 224, 224)

# 运行模型推理
output = model(input_data)
print("ResNet18 模型输出结果:", output)

# 保存输出到文件
output_numpy = output.detach().numpy()
np.savetxt("resnet18_output.txt", output_numpy, fmt="%.6f")
print("模型输出已保存到 resnet18_output.txt")