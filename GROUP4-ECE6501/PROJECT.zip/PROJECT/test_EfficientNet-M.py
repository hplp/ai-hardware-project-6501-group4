import torch
from torchvision.models import efficientnet_b3
import numpy as np

# 加载预训练的 EfficientNet-M 模型
model = efficientnet_b3(pretrained=True)  # EfficientNet-B3 corresponds to EfficientNet-M
model.eval()  # 设置模型为评估模式

# 创建一个随机输入数据（模拟 300x300x3 的图像）
input_data = torch.randn(1, 3, 300, 300)  # Batch size = 1, Channels = 3, Height = 300, Width = 300

# 运行模型推理
output = model(input_data)
print("EfficientNet-M 模型输出结果:", output)

# 保存输出到文件
output_numpy = output.detach().numpy()  # 将 Tensor 转为 NumPy 数组
np.savetxt("efficientnet_m_output.txt", output_numpy, fmt="%.6f")  # 保存为 TXT 文件
print("模型输出已保存到 efficientnet_m_output.txt")
